class WelcomeMessage:
    def __init__(self,name):
        self.name= name


    def welcomeName (self):
        print ("Welcome back " + self.name)

