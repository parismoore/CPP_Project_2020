class WelcomeMessage:
    def __init__(self,name):
        self.name= name


    def welcomeName (self):
        return ("Welcome back " + self.name)

